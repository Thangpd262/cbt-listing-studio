/**
 * printify-content.js v1.8.0
 * - Inject nút Save trên mỗi pfa-market-trends-image
 * - Nhớ design đã lưu qua chrome.storage.local → hiện "✓ Đã lưu" khi quay lại
 */
(function () {
  if (window.__pfyContentInjected) return;
  window.__pfyContentInjected = true;

  // Set các image_url đã lưu (load từ storage khi khởi động)
  let savedUrls = new Set();

  // ── CSS ─────────────────────────────────────────────────────────────────
  const style = document.createElement("style");
  style.textContent = `
    .__pfy-btn {
      position: absolute;
      top: 8px; right: 8px;
      z-index: 9999;
      padding: 5px 11px;
      border-radius: 8px;
      border: none;
      font-family: system-ui, sans-serif;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(0,0,0,.4);
      transition: background .15s;
      background: #ec8a44;
      color: #fff;
      white-space: nowrap;
    }
    .__pfy-btn:hover  { background: #f3a567; }
    .__pfy-btn.saving { background: #c97030; cursor: wait; }
    .__pfy-btn.saved  { background: #56c684; cursor: default; }
    .__pfy-btn.err    { background: #ec6a55; }
  `;
  document.head.appendChild(style);

  // ── Persist saved URLs ───────────────────────────────────────────────────
  const STORAGE_KEY = "pfy_saved_urls";

  async function loadSavedUrls() {
    const data = await chrome.storage.local.get(STORAGE_KEY);
    const arr = data[STORAGE_KEY] || [];
    savedUrls = new Set(arr);
  }

  async function persistUrl(url) {
    savedUrls.add(url);
    // Giữ tối đa 2000 URL gần nhất để tránh storage đầy
    const arr = [...savedUrls].slice(-2000);
    await chrome.storage.local.set({ [STORAGE_KEY]: arr });
  }

  // ── Lưu 1 design ─────────────────────────────────────────────────────────
  async function saveDesign(design, btn) {
    btn.className = "__pfy-btn saving";
    btn.textContent = "⏳";

    try {
      const { token, apiBase } = await chrome.storage.local.get(["token", "apiBase"]);
      const BASE = (apiBase || "https://cbt-crawl.vercel.app").replace(/\/$/, "");

      const r = await fetch(`${BASE}/api/printify?action=ingest`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-crawl-token": token || "",
        },
        body: JSON.stringify([design]),
      });

      if (!r.ok) throw new Error(`HTTP ${r.status}`);

      await persistUrl(design.image_url);
      markSaved(btn);
    } catch (e) {
      btn.className = "__pfy-btn err";
      btn.textContent = "✗ Lỗi";
      setTimeout(() => {
        btn.className = "__pfy-btn";
        btn.textContent = "💾 Save";
      }, 3000);
    }
  }

  function markSaved(btn) {
    btn.className = "__pfy-btn saved";
    btn.textContent = "✓ Đã lưu";
  }

  // ── Gắn nút vào 1 pfa-market-trends-image ───────────────────────────────
  function decoratePfa(pfa) {
    if (pfa.dataset.__pfyDone) return;
    pfa.dataset.__pfyDone = "1";

    const card = pfa.querySelector('div[data-testid="marketTrendsImage"]') ||
                 pfa.querySelector(".card") ||
                 pfa;

    card.style.position = "relative";

    const btn = document.createElement("button");
    btn.className = "__pfy-btn";

    // Lấy src ngay lúc này để check đã lưu chưa
    const imgEl = pfa.querySelector("img.card-image") || pfa.querySelector("img");
    const srcNow = imgEl?.src || "";

    if (srcNow && savedUrls.has(srcNow)) {
      markSaved(btn);
    } else {
      btn.textContent = "💾 Save";
    }

    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (btn.classList.contains("saving") || btn.classList.contains("saved")) return;

      const img = pfa.querySelector("img.card-image") || pfa.querySelector("img");
      const src = img?.src || "";
      if (!src) {
        btn.className = "__pfy-btn err";
        btn.textContent = "✗ Chưa load";
        setTimeout(() => { btn.className = "__pfy-btn"; btn.textContent = "💾 Save"; }, 2000);
        return;
      }

      // Double-check lại trong savedUrls (có thể vừa được lưu tab khác)
      if (savedUrls.has(src)) { markSaved(btn); return; }

      const trendId = src.replace(/\?.*$/, "").split("/").filter(Boolean).pop() || "";
      saveDesign({ trend_id: trendId, image_url: src, title: null, category: null, source_url: location.href }, btn);
    });

    card.appendChild(btn);

    // Nếu lúc gắn btn img chưa load xong → watch src thay đổi
    if (!srcNow && imgEl) {
      const imgObs = new MutationObserver(() => {
        const s = imgEl.src || "";
        if (!s) return;
        imgObs.disconnect();
        if (savedUrls.has(s)) markSaved(btn);
      });
      imgObs.observe(imgEl, { attributes: true, attributeFilter: ["src"] });
    }
  }

  // ── Quét trang ────────────────────────────────────────────────────────────
  function scan() {
    document.querySelectorAll("pfa-market-trends-image").forEach(decoratePfa);
  }

  // ── MutationObserver ─────────────────────────────────────────────────────
  const mo = new MutationObserver(scan);

  async function init() {
    await loadSavedUrls();   // load saved URLs trước khi scan
    scan();
    mo.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    setTimeout(init, 500);
  }

  // Popup polling
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "PRINTIFY_CHECK_TOKEN") {
      const saved = document.querySelectorAll(".__pfy-btn.saved").length;
      sendResponse({ hasToken: true, savedCount: saved });
      return true;
    }
  });
})();
