/**
 * printify-main.js — MAIN world, document_start
 * Angular dùng XHR → intercept setRequestHeader để bắt Bearer token
 */
(function () {
  if (window.__pfyMainInjected) return;
  window.__pfyMainInjected = true;

  let capturedToken = null;

  // ── 1. Intercept XHR để bắt Bearer token ──────────────────────────────
  const _origOpen = XMLHttpRequest.prototype.open;
  const _origSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__pfyUrl = url;
    return _origOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (!capturedToken &&
        name.toLowerCase() === "authorization" &&
        typeof value === "string" &&
        value.startsWith("Bearer ")) {
      capturedToken = value;
      window.postMessage({ type: "__PFY_AUTH_READY", token: capturedToken }, "*");
    }
    return _origSetHeader.apply(this, [name, value]);
  };

  // ── 2. Cũng intercept fetch (phòng khi dùng fetch thay XHR) ───────────
  const _origFetch = window.fetch;
  window.fetch = function (...args) {
    if (!capturedToken) {
      const [input, init] = args;
      const h = init?.headers;
      if (h) {
        const auth = typeof h.get === "function"
          ? (h.get("Authorization") || h.get("authorization"))
          : (h["Authorization"] || h["authorization"]);
        if (auth && auth.startsWith("Bearer ")) {
          capturedToken = auth;
          window.postMessage({ type: "__PFY_AUTH_READY", token: capturedToken }, "*");
        }
      }
    }
    return _origFetch.apply(this, args);
  };

  // ── 3. Nhận lệnh fetch từ isolated world ──────────────────────────────
  window.addEventListener("message", async (e) => {
    if (!e.data) return;

    if (e.data.type === "__PFY_FETCH_REQ") {
      const { id, url } = e.data;
      try {
        const headers = { "Content-Type": "application/json" };
        if (capturedToken) headers["Authorization"] = capturedToken;
        const r = await _origFetch(url, { credentials: "include", headers });
        const text = await r.text();
        console.log("[PFY-MAIN] fetch", url, "→", r.status, text.slice(0, 200));
        window.postMessage({ type: "__PFY_FETCH_RES", id, status: r.status, text }, "*");
      } catch (err) {
        window.postMessage({ type: "__PFY_FETCH_RES", id, status: 0, error: err.message, text: "" }, "*");
      }
    }

    // ── 4. DOM scrape — lấy design images đang render trên trang ────────
    if (e.data.type === "__PFY_DOM_SCRAPE") {
      const { id } = e.data;
      const designs = [];
      const seen = new Set();

      document.querySelectorAll("img").forEach((img) => {
        const src = img.src || img.dataset.src || img.dataset.lazy || "";
        if (!src) return;
        // Lấy ảnh Printify CDN, bỏ icon nhỏ (<50px)
        const isPrintifyCdn = src.includes("cdn.printify.com") || src.includes("printify.com");
        const isSmall = (img.naturalWidth && img.naturalWidth < 50) || (img.naturalHeight && img.naturalHeight < 50);
        if (!isPrintifyCdn || isSmall || seen.has(src)) return;
        seen.add(src);

        // Lấy title từ container gần nhất
        const container = img.closest("[class*='trend'], [class*='design'], [class*='card'], [class*='item'], li, article") || img.parentElement;
        const titleEl = container && container.querySelector("[class*='title'], [class*='name'], h1, h2, h3, h4, p");
        const title = titleEl ? titleEl.textContent.trim().slice(0, 200) : null;

        // Dùng filename làm trend_id
        const trendId = src.replace(/\?.*/, "").split("/").filter(Boolean).pop() || src;

        designs.push({ trend_id: trendId, image_url: src, title, category: null, source_url: location.href });
      });

      console.log("[PFY-DOM] scraped", designs.length, "images");
      window.postMessage({ type: "__PFY_DOM_SCRAPE_RES", id, designs }, "*");
    }
  });
})();
