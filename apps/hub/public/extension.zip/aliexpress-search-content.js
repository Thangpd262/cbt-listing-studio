// aliexpress-search-content.js v1.0.0
// Inject nút Crawl lên từng product card trên trang search/danh mục AliExpress.
// Scrape trực tiếp từ DOM card (AliExpress JS-rendered — không fetch HTML được).
(function () {
  if (window.__aliSearchCrawlerInjected) return;
  window.__aliSearchCrawlerInjected = true;

  // ── Styles ─────────────────────────────────────────────────────────────────
  const style = document.createElement("style");
  style.textContent = `
    .cbt-ali-btn {
      position: absolute;
      bottom: 8px;
      left: 8px;
      z-index: 999;
      background: #c0392b;
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: 5px 10px;
      font-size: 11px;
      font-weight: 700;
      font-family: system-ui, Arial, sans-serif;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(0,0,0,0.45);
      white-space: nowrap;
      line-height: 1.4;
      opacity: 0.95;
      transition: opacity 0.15s, background 0.15s;
    }
    .cbt-ali-btn:hover  { opacity: 1; background: #a93226; }
    .cbt-ali-btn.loading { background: #92400e; cursor: default; }
    .cbt-ali-btn.success { background: #065f46; cursor: default; }
    .cbt-ali-btn.error   { background: #7f1d1d; cursor: default; }
  `;
  document.head.appendChild(style);

  // ── Chuẩn hoá URL ảnh AliExpress CDN về JPG 800x800 ─────────────────────
  function normAliImg(src) {
    if (!src) return src;
    if (src.startsWith("//")) src = "https:" + src;
    src = src.replace(/_\d+x\d+.*$/, "_800x800.jpg");
    src = src.replace(/\.(webp|avif)(\?.*)?$/, ".jpg");
    return src;
  }

  // ── Scrape data từ card DOM ────────────────────────────────────────────────
  function scrapeCard(cardEl, productId, productUrl) {
    let title = null;
    for (const el of [
      cardEl.querySelector("h3"),
      cardEl.querySelector('[class*="title"i]'),
      cardEl.querySelector('[class*="Title"i]'),
      cardEl.querySelector('[class*="name"i]'),
    ]) {
      if (el && el.textContent.trim().length > 3) { title = el.textContent.trim(); break; }
    }

    let price = null;
    const priceEl = cardEl.querySelector(
      '[class*="price"i]:not([class*="origin"i]):not([class*="del"i]):not([class*="old"i])'
    );
    if (priceEl) price = priceEl.textContent.replace(/\s+/g, " ").trim();

    let images = [];
    const imgEl = cardEl.querySelector("img");
    if (imgEl) {
      let src = imgEl.getAttribute("data-src") || imgEl.getAttribute("src") || imgEl.getAttribute("data-lazy-src") || "";
      if (src) images.push(normAliImg(src));
    }
    cardEl.querySelectorAll("img").forEach((im) => {
      let src = im.getAttribute("data-src") || im.getAttribute("src") || "";
      if (!src) return;
      const normalized = normAliImg(src);
      if (images.includes(normalized)) return;
      if (src.includes("aliexpress") || src.includes("alicdn") || src.includes("ae-pic") || /\bae0\d\b/.test(src)) images.push(normalized);
    });
    images = [...new Set(images)].slice(0, 6);

    let shop_name = null;
    const shopEl = cardEl.querySelector('[class*="store"i], [class*="shop"i], [class*="seller"i]');
    if (shopEl) shop_name = shopEl.textContent.trim().replace(/^store:/i, "").trim() || null;

    return { source: "aliexpress", aliexpress_product_id: productId, url: productUrl, title, price, currency: "USD", images, tags: [], description: null, shop_name };
  }

  // ── Gửi lên API ────────────────────────────────────────────────────────────
  async function sendIngest(data) {
    const { token, apiBase } = await new Promise((resolve) =>
      chrome.storage.local.get(["token", "apiBase"], (v) => resolve({
        token: (v.token || "").trim(),
        apiBase: ((v.apiBase || "https://amz-spapi-asin.vercel.app").trim()).replace(/\/$/, ""),
      }))
    );
    if (!token) throw new Error("Chưa có crawl token. Mở popup → dán token → Lưu.");
    const r = await fetch(apiBase + "/api/etsy?action=ingest", {
      method: "POST",
      headers: { "content-type": "application/json", "x-crawl-token": token },
      body: JSON.stringify(data),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "API lỗi " + r.status);
    return j;
  }

  // ── Tìm product cards ──────────────────────────────────────────────────────
  function getCards() {
    const result = [];
    const seenIds = new Set();
    const seenEls = new Set();

    document.querySelectorAll('a[href*="/item/"]').forEach((anchor) => {
      const href = anchor.href || anchor.getAttribute("href") || "";
      const m = href.match(/\/item\/(\d+)/);
      if (!m) return;
      const productId = m[1];
      if (seenIds.has(productId)) return;

      let cardEl = null;
      if (anchor.querySelector("img")) {
        let el = anchor;
        for (let i = 0; i < 4; i++) {
          const p = el.parentElement;
          if (!p) break;
          const h = p.offsetHeight;
          if (h > 500) break;
          el = p;
          if (h > 150 && p.offsetWidth > 100) cardEl = p;
        }
        if (!cardEl) cardEl = anchor;
      } else {
        let el = anchor.parentElement;
        for (let i = 0; i < 8; i++) {
          if (!el) break;
          const h = el.offsetHeight;
          if (h > 700) break;
          if (el.querySelector("img") && h > 100 && el.offsetWidth > 100) { cardEl = el; break; }
          el = el.parentElement;
        }
      }

      if (cardEl && !seenEls.has(cardEl)) {
        seenIds.add(productId);
        seenEls.add(cardEl);
        result.push({ el: cardEl, productId, productUrl: "https://www.aliexpress.com/item/" + productId + ".html" });
      }
    });
    return result;
  }

  // ── Thêm nút vào card ──────────────────────────────────────────────────────
  function addButtonToCard({ el, productId, productUrl }) {
    if (el.querySelector(".cbt-ali-btn")) return;
    if (getComputedStyle(el).position === "static") el.style.position = "relative";

    const btn = document.createElement("button");
    btn.className = "cbt-ali-btn";
    btn.textContent = "📋 Crawl";
    btn.title = "Crawl sản phẩm này về Studio";
    el.appendChild(btn);

    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (btn.classList.contains("loading") || btn.classList.contains("success")) return;
      btn.classList.add("loading");
      btn.textContent = "⏳…";
      try {
        const data = scrapeCard(el, productId, productUrl);
        if (!data.title && data.images.length === 0) throw new Error("Không đọc được data từ card");
        await sendIngest(data);
        btn.classList.remove("loading");
        btn.classList.add("success");
        btn.textContent = "✓ " + data.images.length + "🖼";
      } catch (err) {
        btn.classList.remove("loading");
        btn.classList.add("error");
        btn.textContent = "✗";
        btn.title = err.message;
        setTimeout(() => {
          btn.classList.remove("error");
          btn.textContent = "📋 Crawl";
          btn.title = "Crawl sản phẩm này về Studio";
        }, 4000);
      }
    });
  }

  // ── Inject + observe ───────────────────────────────────────────────────────
  function injectAll() {
    getCards().forEach(addButtonToCard);
  }

  if (document.body) injectAll();
  else document.addEventListener("DOMContentLoaded", injectAll);

  let debounce = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounce);
    debounce = setTimeout(injectAll, 700);
  });
  observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
})();
