// popup.js — AMZ Listing Crawler v1.9.0

const $ = (id) => document.getElementById(id);

// ── Toast ──────────────────────────────────────────────────────────────────
function toast(msg, kind) {
  const el = $("toast");
  el.textContent = msg;
  el.className = kind || "info";
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.className = ""; el.textContent = ""; }, 4000);
}

// ── Load saved settings ────────────────────────────────────────────────────
chrome.storage.local.get(["token", "apiBase"], (v) => {
  if (v.token) $("token").value = v.token;
  if (v.apiBase) $("apiBase").value = v.apiBase;
});

// ── Save settings ──────────────────────────────────────────────────────────
$("btnSave").addEventListener("click", () => {
  const token = $("token").value.trim();
  const apiBase = $("apiBase").value.trim() || "https://cbt-crawl.vercel.app";
  chrome.storage.local.set({ token, apiBase }, () => {
    if (chrome.runtime.lastError) {
      toast("Loi luu: " + chrome.runtime.lastError.message, "err");
    } else {
      toast("Da luu cai dat!", "ok");
    }
  });
});

// ── Helpers ────────────────────────────────────────────────────────────────
function getSettings() {
  return {
    token: $("token").value.trim(),
    apiBase: ($("apiBase").value.trim() || "https://cbt-crawl.vercel.app").replace(/\/$/, ""),
  };
}

// ── Etsy scraper (chay trong page context) ─────────────────────────────────
function scrapeEtsy() {
  const out = { url: location.href, etsy_listing_id: null, title: null, price: null, currency: null, tags: [], description: null, shop_name: null, images: [] };
  const m = location.pathname.match(/\/listing\/(\d+)/);
  if (m) out.etsy_listing_id = m[1];
  try {
    const blocks = [...document.querySelectorAll('script[type="application/ld+json"]')];
    for (const b of blocks) {
      let j; try { j = JSON.parse(b.textContent); } catch (e) { continue; }
      const arr = Array.isArray(j) ? j : [j];
      for (const node of arr) {
        const t = node && node["@type"];
        if (t === "Product" || (Array.isArray(t) && t.includes("Product"))) {
          out.title = out.title || node.name || null;
          out.description = out.description || node.description || null;
          if (node.image) { const imgs = Array.isArray(node.image) ? node.image : [node.image]; imgs.forEach((x) => { const u = typeof x === "string" ? x : (x && (x.contentURL || x.url || x.thumbnail)); if (u) out.images.push(u); }); }
          const offers = node.offers && (Array.isArray(node.offers) ? node.offers[0] : node.offers);
          if (offers) { out.price = out.price || offers.price || null; out.currency = out.currency || offers.priceCurrency || null; }
          if (node.brand && node.brand.name) out.shop_name = out.shop_name || node.brand.name;
        }
      }
    }
  } catch (e) {}
  if (!out.title) { const h1 = document.querySelector("h1"); if (h1) out.title = h1.textContent.trim(); }
  document.querySelectorAll("ul[data-palette-listing-images] img, .listing-page-image-carousel-component img").forEach((im) => {
    let src = im.getAttribute("src") || "";
    const ss = im.getAttribute("srcset");
    if (ss) { const parts = ss.split(",").map((x) => x.trim().split(" ")[0]); if (parts.length) src = parts[parts.length - 1]; }
    if (src && /il_/.test(src)) out.images.push(src);
  });
  const tagDL = [...document.querySelectorAll("dl")].find(dl => [...dl.querySelectorAll("dt")].some(dt => /Tags/.test(dt.textContent)));
  if (tagDL) { const tagsDT = [...tagDL.querySelectorAll("dt")].find(dt => /Tags/.test(dt.textContent)); const tagDD = tagsDT && tagsDT.nextElementSibling; if (tagDD) out.tags = [...tagDD.querySelectorAll("a")].map(a => a.textContent.trim()).filter(t => t && t.length <= 40).slice(0, 20); }
  if (!out.tags.length) { const tags = new Set(); document.querySelectorAll('a[href*="/market/"], a[href*="search?q="]').forEach((a) => { const t = a.textContent.trim(); if (t && t.length <= 40 && !/http/.test(t)) tags.add(t); }); out.tags = [...tags].slice(0, 20); }
  const seen = new Set(); const finalImgs = [];
  out.images.forEach((u) => {
    if (!u) return;
    const full = u.replace(/il_\d+x\d+/, "il_fullxfull");
    const mm = full.match(/il_[^.]+\.(\d+)_/); const id = mm ? mm[1] : full;
    if (!seen.has(id)) { seen.add(id); finalImgs.push(full); }
  });
  out.images = finalImgs.slice(0, 12);
  return out;
}

// ── AliExpress scraper ─────────────────────────────────────────────────────
function scrapeAliexpress() {
  const out = { url: location.href, source: "aliexpress", aliexpress_product_id: null, title: null, price: null, currency: "USD", tags: [], description: null, shop_name: null, images: [] };
  const m = location.pathname.match(/\/item\/(\d+)\.html/);
  if (m) out.aliexpress_product_id = m[1];
  try {
    const rp = window.runParams && (window.runParams.data || window.runParams);
    if (rp) {
      const titleMod = rp.titleModule || (rp.componentDataMap && rp.componentDataMap.titleModule);
      if (titleMod && titleMod.subject) out.title = titleMod.subject;
      const priceMod = rp.priceModule || (rp.componentDataMap && rp.componentDataMap.priceModule);
      if (priceMod) out.price = priceMod.formatedActivityPrice || priceMod.formatedPrice || null;
      const imgMod = rp.imageModule || (rp.componentDataMap && rp.componentDataMap.imageModule);
      if (imgMod && imgMod.imagePathList) out.images = imgMod.imagePathList.map((p) => (p.startsWith("http") ? p : "https:" + p)).slice(0, 12);
      const storeMod = rp.storeModule || (rp.componentDataMap && rp.componentDataMap.storeModule);
      if (storeMod && storeMod.storeName) out.shop_name = storeMod.storeName;
    }
  } catch (e) {}
  if (!out.title) { const h1 = document.querySelector("h1"); if (h1) out.title = h1.textContent.trim(); }
  if (out.images.length === 0) {
    const seen = new Set();
    document.querySelectorAll(".magnifier-image, .images-view-item img").forEach((im) => {
      let src = im.getAttribute("src") || "";
      if (src && src.includes("aliexpress") && !seen.has(src)) { seen.add(src); out.images.push(src.replace(/_\d+x\d+\.jpg/, "_960x960.jpg")); }
    });
    out.images = out.images.slice(0, 12);
  }
  return out;
}

// ── Crawl Etsy/AliExpress ──────────────────────────────────────────────────
$("btnCrawl").addEventListener("click", async () => {
  const { token, apiBase } = getSettings();
  if (!token) { toast("Chua nhap crawl token.", "err"); return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab && tab.url || "";
  const isEtsy = /etsy\.com\/listing\//.test(url);
  const isAli = /aliexpress\.us\/item\//.test(url);
  if (!isEtsy && !isAli) { toast("Mo trang san pham Etsy hoac AliExpress US truoc.", "err"); return; }
  toast("Dang doc trang...", "info");
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: isAli ? scrapeAliexpress : scrapeEtsy });
    const data = res.result;
    if (!data || !data.title) { toast("Khong tim thay du lieu tren trang nay.", "err"); return; }
    toast("Dang gui ve AMZ...", "info");
    const r = await fetch(apiBase + "/api/etsy?action=ingest", {
      method: "POST",
      headers: { "content-type": "application/json", "x-crawl-token": token },
      body: JSON.stringify(data),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok) toast("OK: " + (data.title || "").slice(0, 50) + " | " + data.images.length + " anh", "ok");
    else toast("Loi " + r.status + ": " + (j.error || ""), "err");
  } catch (e) { toast("Loi: " + e.message, "err"); }
});

// ── Crawl TM ───────────────────────────────────────────────────────────────
$("btnCrawlTm").addEventListener("click", async () => {
  const { token, apiBase } = getSettings();
  if (!token) { toast("Chua nhap crawl token.", "err"); return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  toast("Dang crawl TM...", "info");
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => location.href });
    const r = await fetch(apiBase + "/api/tm-crawl", {
      method: "POST",
      headers: { "content-type": "application/json", "x-crawl-token": token },
      body: JSON.stringify({ url: res.result }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok) toast("OK TM: " + (j.name || ""), "ok");
    else toast("Loi " + r.status + ": " + (j.error || ""), "err");
  } catch (e) { toast("Loi: " + e.message, "err"); }
});

// ── Printify section ───────────────────────────────────────────────────────
(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/printify\.com\/app\/trends/.test(tab.url || "")) return;

  $("sectionPrintify").style.display = "block";
  $("sectionEtsy").style.display = "none";

  const selectedEl = $("pfySelected");

  // Poll số design đang được chọn trên trang
  function pollSelected() {
    chrome.tabs.sendMessage(tab.id, { type: "PRINTIFY_CHECK_TOKEN" }, (resp) => {
      if (chrome.runtime.lastError || !resp) return;
      const n = resp.savedCount || 0;
      selectedEl.textContent = n > 0
        ? `✅ Đã lưu ${n} design trong phiên này`
        : "Chưa lưu design nào";
      selectedEl.style.color = n > 0 ? "#6ddba0" : "var(--faint)";
    });
  }

  pollSelected();
  const timer = setInterval(pollSelected, 1500);
  window.addEventListener("unload", () => clearInterval(timer));
})();
