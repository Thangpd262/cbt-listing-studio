// etsy-search-content.js v1.0.0
// Inject nút Crawl lên từng listing card trên trang search/shop/category Etsy.
// Fetch HTML listing trực tiếp (dùng cookie user) — không mở tab ẩn.
(function () {
  if (window.__etsySearchCrawlerInjected) return;
  window.__etsySearchCrawlerInjected = true;

  // ── Styles ─────────────────────────────────────────────────────────────────
  const styleEl = document.createElement("style");
  styleEl.textContent = `
    .cbt-crawl-card-btn {
      position: absolute;
      bottom: 44px;
      left: 8px;
      z-index: 999;
      background: #111827;
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: 5px 9px;
      font-size: 11px;
      font-weight: 700;
      font-family: system-ui, Arial, sans-serif;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(0,0,0,0.4);
      white-space: nowrap;
      line-height: 1.4;
      opacity: 0.92;
      transition: opacity 0.15s;
    }
    .cbt-crawl-card-btn:hover { opacity: 1; }
    .cbt-crawl-card-btn.loading { background: #92400e; cursor: default; }
    .cbt-crawl-card-btn.success { background: #065f46; cursor: default; }
    .cbt-crawl-card-btn.error   { background: #7f1d1d; cursor: default; }
    .cbt-crawl-card-btn.tm-btn  { background: #5b21b6; bottom: 72px; }
  `;
  document.head.appendChild(styleEl);

  // ── Parse listing từ HTML string ───────────────────────────────────────────
  function parseEtsyHtml(html, url) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const out = {
      url,
      etsy_listing_id: (url.match(/\/listing\/(\d+)/) || [])[1] || null,
      title: null, price: null, currency: null,
      tags: [], description: null, shop_name: null, images: [],
    };

    // JSON-LD
    for (const el of doc.querySelectorAll('script[type="application/ld+json"]')) {
      let j; try { j = JSON.parse(el.textContent); } catch (e) { continue; }
      const arr = Array.isArray(j) ? j : [j];
      for (const node of arr) {
        const t = node && node["@type"];
        if (t === "Product" || (Array.isArray(t) && t.includes("Product"))) {
          out.title = out.title || node.name || null;
          out.description = out.description || node.description || null;
          if (node.image) {
            const imgs = Array.isArray(node.image) ? node.image : [node.image];
            imgs.forEach((x) => {
              const u = typeof x === "string" ? x : (x && (x.contentURL || x.url || x.thumbnail));
              if (u) out.images.push(u);
            });
          }
          const offers = node.offers && (Array.isArray(node.offers) ? node.offers[0] : node.offers);
          if (offers) {
            out.price = out.price || offers.price || null;
            out.currency = out.currency || offers.priceCurrency || null;
          }
          if (node.brand && node.brand.name) out.shop_name = out.shop_name || node.brand.name;
        }
      }
    }

    // DOM fallback
    if (!out.title) { const h = doc.querySelector("h1"); if (h) out.title = h.textContent.trim(); }
    if (!out.shop_name) { const s = doc.querySelector('a[href*="/shop/"] span, [data-shop-name]'); if (s) out.shop_name = s.textContent.trim(); }

    // Ảnh từ carousel
    doc.querySelectorAll("ul[data-palette-listing-images] img, .listing-page-image-carousel-component img").forEach((im) => {
      let src = im.getAttribute("src") || "";
      const ss = im.getAttribute("srcset");
      if (ss) { const parts = ss.split(",").map((x) => x.trim().split(" ")[0]); if (parts.length) src = parts[parts.length - 1]; }
      if (src && /il_/.test(src)) out.images.push(src);
    });

    // Tags — dùng DL/DT("Tags")/DD/a (chính xác), fallback về search?q=
    const tagDL = [...doc.querySelectorAll("dl")].find(dl =>
      [...dl.querySelectorAll("dt")].some(dt => /Tags/.test(dt.textContent))
    );
    if (tagDL) {
      const tagsDT = [...tagDL.querySelectorAll("dt")].find(dt => /Tags/.test(dt.textContent));
      const tagDD = tagsDT && tagsDT.nextElementSibling;
      if (tagDD) out.tags = [...tagDD.querySelectorAll("a")].map(a => a.textContent.trim()).filter(t => t && t.length <= 40).slice(0, 20);
    }
    if (!out.tags.length) {
      const tags = new Set();
      doc.querySelectorAll('a[href*="/market/"], a[href*="search?q="]').forEach((a) => {
        const t = a.textContent.trim();
        if (t && t.length <= 40 && !/http/.test(t)) tags.add(t);
      });
      out.tags = [...tags].slice(0, 20);
    }

    // Dedupe + fullsize ảnh
    const seen = new Set(); const finalImgs = [];
    out.images.forEach((u) => {
      if (!u || typeof u !== "string") return;
      const full = u.replace(/il_\d+x\d+/, "il_fullxfull");
      const mm = full.match(/il_[^.]+\.(\d+)_/); const id = mm ? mm[1] : full;
      if (!seen.has(id)) { seen.add(id); finalImgs.push(full); }
    });
    out.images = finalImgs.slice(0, 12);
    return out;
  }

  // ── Crawl 1 listing URL ────────────────────────────────────────────────────
  async function crawlUrl(url, purpose) {
    const { token, apiBase } = await new Promise((resolve) =>
      chrome.storage.local.get(["token", "apiBase"], (v) => resolve({
        token: (v.token || "").trim(),
        apiBase: ((v.apiBase || "https://amz-spapi-asin.vercel.app").trim()).replace(/\/$/, ""),
      }))
    );
    if (!token) throw new Error("Chưa có crawl token. Mở popup → dán token → Lưu.");

    const html = await fetch(url, { credentials: "include" }).then((r) => {
      if (!r.ok) throw new Error("Fetch lỗi HTTP " + r.status);
      return r.text();
    });

    const data = parseEtsyHtml(html, url);
    if (!data.title) throw new Error("Không đọc được dữ liệu listing");
    data.crawl_purpose = purpose || "normal";

    const r = await fetch(apiBase + "/api/etsy?action=ingest", {
      method: "POST",
      headers: { "content-type": "application/json", "x-crawl-token": token },
      body: JSON.stringify(data),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "API lỗi " + r.status);
    return { title: data.title, images: data.images.length, tags: data.tags.length };
  }

  // ── Queue ──────────────────────────────────────────────────────────────────
  const queue = [];
  let qRunning = false;

  function enqueue(url, purpose) {
    return new Promise((resolve, reject) => {
      queue.push({ url, purpose, resolve, reject });
      runQueue();
    });
  }

  async function runQueue() {
    if (qRunning || queue.length === 0) return;
    qRunning = true;
    while (queue.length > 0) {
      const { url, purpose, resolve, reject } = queue.shift();
      try { resolve(await crawlUrl(url, purpose)); }
      catch (e) { reject(e); }
    }
    qRunning = false;
  }

  // ── Tìm listing cards ──────────────────────────────────────────────────────
  function getCards() {
    const set = new Set();
    [...document.querySelectorAll("li[data-listing-id], div[data-listing-id], div.v2-listing-card")].forEach((el) => set.add(el));
    if (set.size === 0) {
      document.querySelectorAll('a[href*="/listing/"]').forEach((a) => {
        let el = a;
        for (let i = 0; i < 5; i++) {
          el = el.parentElement;
          if (!el) break;
          const tag = el.tagName.toLowerCase();
          if ((tag === "li" || tag === "div") && el.offsetHeight > 100 && !set.has(el)) { set.add(el); break; }
        }
      });
    }
    return [...set];
  }

  function getListingUrl(card) {
    const id = card.dataset.listingId || card.dataset.id;
    if (id && /^\d+$/.test(id)) return "https://www.etsy.com/listing/" + id;
    const a = card.querySelector('a[href*="/listing/"]');
    if (a) { const m = a.href.match(/etsy\.com\/listing\/(\d+)/); if (m) return "https://www.etsy.com/listing/" + m[1]; }
    return null;
  }

  // ── Thêm nút vào card ──────────────────────────────────────────────────────
  function addButtonToCard(card) {
    if (card.querySelector(".cbt-crawl-card-btn")) return;
    const url = getListingUrl(card);
    if (!url) return;
    if (getComputedStyle(card).position === "static") card.style.position = "relative";

    const btn = document.createElement("button");
    btn.className = "cbt-crawl-card-btn";
    btn.textContent = "📋 Crawl";
    btn.title = "Crawl listing về Studio";

    const btnTm = document.createElement("button");
    btnTm.className = "cbt-crawl-card-btn tm-btn";
    btnTm.textContent = "🎨 TM";
    btnTm.title = "Crawl để phát triển nhân vật TM";

    card.appendChild(btn);
    card.appendChild(btnTm);

    function doClick(purpose) {
      if (btn.classList.contains("loading") || btn.classList.contains("success")) return;
      btn.classList.add("loading"); btnTm.classList.add("loading");
      btn.textContent = "⏳…"; btnTm.textContent = "⏳";

      enqueue(url, purpose)
        .then((r) => {
          btn.classList.remove("loading"); btnTm.classList.remove("loading");
          btn.classList.add("success"); btnTm.classList.add("success");
          btn.textContent = "✓ " + r.images + "🖼 · " + r.tags + "🏷";
          btnTm.textContent = purpose === "tm" ? "✓ TM" : "✓";
        })
        .catch((e) => {
          btn.classList.remove("loading"); btnTm.classList.remove("loading");
          btn.classList.add("error"); btnTm.classList.add("error");
          btn.textContent = "✗"; btn.title = e.message;
          btnTm.textContent = "✗"; btnTm.title = e.message;
          setTimeout(() => {
            btn.classList.remove("error"); btnTm.classList.remove("error");
            btn.textContent = "📋 Crawl"; btnTm.textContent = "🎨 TM";
            btn.title = "Crawl listing về Studio"; btnTm.title = "Crawl để phát triển nhân vật TM";
          }, 4000);
        });
    }

    btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); doClick("normal"); });
    btnTm.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); doClick("tm"); });
  }

  // ── Inject + observe ───────────────────────────────────────────────────────
  function injectAll() {
    getCards().forEach(addButtonToCard);
  }

  if (document.body) injectAll();
  else document.addEventListener("DOMContentLoaded", injectAll);

  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(injectAll, 600);
  });
  observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
})();
