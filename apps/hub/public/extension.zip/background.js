// background.js — CBT Listing Crawler service worker v1.9.0
// Xử lý crawl listing Etsy từ search page (mở tab ẩn → scrape → đóng tab)

// ── Etsy scraper (inject vào listing tab) ─────────────────────────────────
// Hàm này được serialize và inject vào tab, KHÔNG dùng closure bên ngoài.
function scrapeEtsyInPage() {
  const out = {
    url: location.href,
    etsy_listing_id: null,
    title: null, price: null, currency: null,
    tags: [], description: null, shop_name: null, images: [],
  };
  const m = location.pathname.match(/\/listing\/(\d+)/);
  if (m) out.etsy_listing_id = m[1];

  // 1) JSON-LD
  try {
    for (const b of document.querySelectorAll('script[type="application/ld+json"]')) {
      let j; try { j = JSON.parse(b.textContent); } catch (e) { continue; }
      const arr = Array.isArray(j) ? j : [j];
      for (const node of arr) {
        const t = node && node["@type"];
        if (t === "Product" || (Array.isArray(t) && t.includes("Product"))) {
          out.title = out.title || node.name || null;
          out.description = out.description || node.description || null;
          if (node.image) {
            const imgs = Array.isArray(node.image) ? node.image : [node.image];
            imgs.forEach((x) => {
              const u = typeof x === "string" ? x : (x && (x.contentURL || x.url || x.thumbnail));
              if (u) out.images.push(u);
            });
          }
          const offers = node.offers && (Array.isArray(node.offers) ? node.offers[0] : node.offers);
          if (offers) {
            out.price = out.price || offers.price || (offers.priceSpecification && offers.priceSpecification.price) || null;
            out.currency = out.currency || offers.priceCurrency || (offers.priceSpecification && offers.priceSpecification.priceCurrency) || null;
          }
          if (node.brand && node.brand.name) out.shop_name = out.shop_name || node.brand.name;
        }
      }
    }
  } catch (e) {}

  // 2) DOM fallback
  if (!out.title) { const h1 = document.querySelector("h1"); if (h1) out.title = h1.textContent.trim(); }
  if (!out.price) { const p = document.querySelector('[data-buy-box-region="price"], .wt-text-title-larger'); if (p) out.price = p.textContent.replace(/\s+/g, " ").trim(); }
  if (!out.shop_name) { const s = document.querySelector('a[href*="/shop/"] span, [data-shop-name]'); if (s) out.shop_name = s.textContent.trim(); }

  // 3) Ảnh từ carousel
  document.querySelectorAll("ul[data-palette-listing-images] img, .listing-page-image-carousel-component img").forEach((im) => {
    let src = im.getAttribute("src") || "";
    const ss = im.getAttribute("srcset");
    if (ss) { const parts = ss.split(",").map((x) => x.trim().split(" ")[0]); if (parts.length) src = parts[parts.length - 1]; }
    if (src && /il_/.test(src)) out.images.push(src);
  });

  // 4) Tags — DL/DT("Tags")/DD/a (chính xác), fallback về search?q=
  const tagDL = [...document.querySelectorAll("dl")].find(dl =>
    [...dl.querySelectorAll("dt")].some(dt => /Tags/.test(dt.textContent))
  );
  if (tagDL) {
    const tagsDT = [...tagDL.querySelectorAll("dt")].find(dt => /Tags/.test(dt.textContent));
    const tagDD = tagsDT && tagsDT.nextElementSibling;
    if (tagDD) out.tags = [...tagDD.querySelectorAll("a")].map(a => a.textContent.trim()).filter(t => t && t.length <= 40).slice(0, 20);
  }
  if (!out.tags.length) {
    const tags = new Set();
    document.querySelectorAll('a[href*="/market/"], a[href*="search?q="]').forEach((a) => {
      const t = a.textContent.trim();
      if (t && t.length <= 40 && !/http/.test(t)) tags.add(t);
    });
    out.tags = [...tags].slice(0, 20);
  }

  // 5) Dedupe + fullsize ảnh
  const seen = new Set(); const finalImgs = [];
  out.images.forEach((u) => {
    if (!u || typeof u !== "string") return;
    const full = u.replace(/il_\d+x\d+/, "il_fullxfull");
    const mm = full.match(/il_[^.]+\.(\d+)_/); const id = mm ? mm[1] : full;
    if (!seen.has(id)) { seen.add(id); finalImgs.push(full); }
  });
  out.images = finalImgs.slice(0, 12);
  return out;
}

// ── Chờ tab load xong ─────────────────────────────────────────────────────
function waitForTabLoad(tabId, timeout = 20000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Tab load timeout"));
    }, timeout);

    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(resolve, 1800);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// ── Gửi data lên API ──────────────────────────────────────────────────────
async function sendToApi(apiBase, token, data) {
  const r = await fetch(apiBase + "/api/etsy?action=ingest", {
    method: "POST",
    headers: { "content-type": "application/json", "x-crawl-token": token },
    body: JSON.stringify(data),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || "HTTP " + r.status);
  return j;
}

// ── Queue: tránh mở nhiều tab cùng lúc ───────────────────────────────────
const queue = [];
let running = false;

async function processQueue() {
  if (running || queue.length === 0) return;
  running = true;
  while (queue.length > 0) {
    const { url, purpose, token, apiBase, resolve, reject } = queue.shift();
    let tabId = null;
    try {
      const tab = await chrome.tabs.create({ url, active: false });
      tabId = tab.id;
      await waitForTabLoad(tabId);
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        func: scrapeEtsyInPage,
      });
      const data = result.result;
      if (!data || !data.title) throw new Error("Không đọc được dữ liệu listing");
      data.crawl_purpose = purpose || "normal";
      await sendToApi(apiBase, token, data);
      resolve({ ok: true, title: data.title, images: data.images.length, tags: data.tags.length });
    } catch (e) {
      reject(e);
    } finally {
      if (tabId !== null) chrome.tabs.remove(tabId).catch(() => {});
    }
  }
  running = false;
}

// ── Lắng nghe message từ content script ──────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "CRAWL_LISTING_URL") return false;

  const { url, purpose } = msg;
  chrome.storage.local.get(["token", "apiBase"], (v) => {
    const token = (v.token || "").trim();
    const apiBase = ((v.apiBase || "https://amz-spapi-asin.vercel.app").trim()).replace(/\/$/, "");
    if (!token) {
      sendResponse({ ok: false, error: "Chưa có crawl token. Mở popup extension → dán token → Lưu." });
      return;
    }
    new Promise((resolve, reject) => {
      queue.push({ url, purpose, token, apiBase, resolve, reject });
      processQueue();
    })
      .then((r) => sendResponse({ ok: true, ...r }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
  });

  return true; // async response
});
