// Chèn nút "Crawl → AMZ" nổi cố định trên trang listing Etsy & AliExpress US (luôn hiện khi cuộn).
(function () {
  if (window.__amzCrawlerInjected) return;
  window.__amzCrawlerInjected = true;

  // ── Chuẩn hoá URL ảnh AliExpress CDN về JPG 800x800 ──────────────────────
  // CDN cũ: ae01.alicdn.com/kf/S123.jpg_640x640.webp
  // CDN mới: ae-pic-a1.aliexpress-media.com/kf/S123.jpg_220x220q75.jpg_.avif
  // → strip mọi thứ từ _NxN trở đi, thay bằng _800x800.jpg
  function normAliImg(src) {
    if (!src) return src;
    if (src.startsWith("//")) src = "https:" + src;
    src = src.replace(/_\d+x\d+.*$/, "_800x800.jpg");
    src = src.replace(/\.(webp|avif)(\?.*)?$/, ".jpg");
    return src;
  }

  // ── AliExpress US scraper ───────────────────────────────────────────────
  function scrapeAliexpress() {
    const out = { url: location.href, source: "aliexpress", aliexpress_product_id: null, title: null, price: null, currency: "USD", tags: [], description: null, shop_name: null, images: [] };
    const m = location.pathname.match(/\/item\/(\d+)/);
    if (m) out.aliexpress_product_id = m[1];

    // 1) window.runParams — nguồn đáng tin nhất
    try {
      const rp = window.runParams && (window.runParams.data || window.runParams);
      if (rp) {
        const titleMod = rp.titleModule || (rp.componentDataMap && rp.componentDataMap.titleModule);
        if (titleMod && titleMod.subject) out.title = titleMod.subject;

        const priceMod = rp.priceModule || (rp.componentDataMap && rp.componentDataMap.priceModule);
        if (priceMod) out.price = priceMod.formatedActivityPrice || priceMod.formatedPrice || (priceMod.minAmount && priceMod.minAmount.formatedAmount) || null;

        const imgMod = rp.imageModule || (rp.componentDataMap && rp.componentDataMap.imageModule);
        if (imgMod && imgMod.imagePathList) out.images = imgMod.imagePathList.map((p) => normAliImg(p.startsWith("http") ? p : "https:" + p)).slice(0, 12);

        const storeMod = rp.storeModule || (rp.componentDataMap && rp.componentDataMap.storeModule);
        if (storeMod && storeMod.storeName) out.shop_name = storeMod.storeName;

        const specsMod = rp.specsModule || (rp.componentDataMap && rp.componentDataMap.specsModule);
        if (specsMod && specsMod.props) {
          specsMod.props.forEach((p) => { if (p.attrName && p.attrValue) out.tags.push(p.attrName + ": " + p.attrValue); });
          out.tags = out.tags.slice(0, 20);
        }

        const descMod = rp.descriptionModule || (rp.componentDataMap && rp.componentDataMap.descriptionModule);
        if (descMod && descMod.descriptionUrl) out.description = descMod.descriptionUrl;
      }
    } catch (e) {}

    // 2) DOM fallback
    if (!out.title) { const h1 = document.querySelector('h1[data-pl="product-title"], h1.product-title-text, h1'); if (h1) out.title = h1.textContent.trim(); }
    if (!out.price) { const p = document.querySelector('.product-price-value, .uniform-banner-box-price, [data-pl="product-price"]'); if (p) out.price = p.textContent.replace(/\s+/g, " ").trim(); }
    if (!out.shop_name) { const s = document.querySelector('.shop-name, .store-info-name, a[href*="/store/"] span'); if (s) out.shop_name = s.textContent.trim(); }
    if (out.images.length === 0) {
      const seen = new Set();
      document.querySelectorAll('.magnifier-image, .images-view-item img, .slider-img img, [class*="image"] img, [class*="slider"] img, [class*="gallery"] img').forEach((im) => {
        let src = im.getAttribute("src") || im.getAttribute("data-src") || "";
        if (src && (src.includes("aliexpress") || src.includes("alicdn") || src.includes("ae-pic")) && !seen.has(src)) { seen.add(src); out.images.push(normAliImg(src)); }
      });
      out.images = out.images.slice(0, 12);
    }
    return out;
  }

  // ── Etsy scraper ────────────────────────────────────────────────────────
  function scrapeEtsy() {
    const out = { url: location.href, etsy_listing_id: null, title: null, price: null, currency: null, tags: [], description: null, shop_name: null, images: [] };
    const m = location.pathname.match(/\/listing\/(\d+)/);
    if (m) out.etsy_listing_id = m[1];
    try {
      const blocks = [...document.querySelectorAll('script[type="application/ld+json"]')];
      for (const b of blocks) {
        let j; try { j = JSON.parse(b.textContent); } catch (e) { continue; }
        const arr = Array.isArray(j) ? j : [j];
        for (const node of arr) {
          const t = node && node["@type"];
          if (t === "Product" || (Array.isArray(t) && t.includes("Product"))) {
            out.title = out.title || node.name || null;
            out.description = out.description || node.description || null;
            if (node.image) { const imgs = Array.isArray(node.image) ? node.image : [node.image]; imgs.forEach((x) => { const u = typeof x === "string" ? x : (x && (x.contentURL || x.url || x.thumbnail)); if (u) out.images.push(u); }); }
            const offers = node.offers && (Array.isArray(node.offers) ? node.offers[0] : node.offers);
            if (offers) { out.price = out.price || offers.price || (offers.priceSpecification && offers.priceSpecification.price) || null; out.currency = out.currency || offers.priceCurrency || (offers.priceSpecification && offers.priceSpecification.priceCurrency) || null; }
            if (node.brand && node.brand.name) out.shop_name = out.shop_name || node.brand.name;
          }
        }
      }
    } catch (e) {}
    if (!out.title) { const h1 = document.querySelector("h1"); if (h1) out.title = h1.textContent.trim(); }
    if (!out.price) { const p = document.querySelector('[data-buy-box-region="price"], .wt-text-title-larger'); if (p) out.price = p.textContent.replace(/\s+/g, " ").trim(); }
    if (!out.shop_name) { const s = document.querySelector('a[href*="/shop/"] span, [data-shop-name]'); if (s) out.shop_name = s.textContent.trim(); }
    // Gộp thêm ảnh từ carousel CỦA LISTING (không quét toàn trang) -> lấy đủ ảnh, dedupe phía dưới
    document.querySelectorAll('ul[data-palette-listing-images] img, .listing-page-image-carousel-component img').forEach((im) => {
      let src = im.getAttribute("src") || "";
      const ss = im.getAttribute("srcset");
      if (ss) { const parts = ss.split(",").map((x) => x.trim().split(" ")[0]); if (parts.length) src = parts[parts.length - 1]; }
      if (src && /il_/.test(src)) out.images.push(src);
    });
    // Tags: ưu tiên DL/DT("Tags")/DD/a — cấu trúc chính xác của Etsy
    // (selector cũ a[href*="/market/"] đã obsolete; a[href*="search?q="] match 60+ links không liên quan)
    const tagDL = [...document.querySelectorAll('dl')].find(dl => [...dl.querySelectorAll('dt')].some(dt => /Tags/.test(dt.textContent)));
    if (tagDL) {
      const tagsDT = [...tagDL.querySelectorAll('dt')].find(dt => /Tags/.test(dt.textContent));
      const tagDD = tagsDT && tagsDT.nextElementSibling;
      if (tagDD) out.tags = [...tagDD.querySelectorAll('a')].map(a => a.textContent.trim()).filter(t => t && t.length <= 40).slice(0, 20);
    }
    // Fallback nếu DL structure không tìm được
    if (!out.tags.length) {
      const tagEls = document.querySelectorAll('a[href*="/market/"], a[href*="search?q="]');
      const tags = new Set();
      tagEls.forEach((a) => { const t = a.textContent.trim(); if (t && t.length <= 40 && !/http/.test(t)) tags.add(t); });
      out.tags = [...tags].slice(0, 20);
    }
    // Chuẩn hoá full + dedupe theo image-id (gộp các cỡ của cùng 1 ảnh)
    const seen = new Set(); const finalImgs = [];
    out.images.forEach((u) => {
      if (!u || typeof u !== "string") return;
      const full = u.replace(/il_\d+x\d+/, "il_fullxfull");
      const m = full.match(/il_[^.]+\.(\d+)_/); const id = m ? m[1] : full;
      if (!seen.has(id)) { seen.add(id); finalImgs.push(full); }
    });
    out.images = finalImgs.slice(0, 12);
    return out;
  }

  function build() {
    if (document.getElementById("amz-crawl-btn")) return;
    const wrap = document.createElement("div");
    wrap.id = "amz-crawl-btn";
    wrap.style.cssText = "position:fixed;right:20px;bottom:20px;z-index:2147483647;font-family:system-ui,Arial,sans-serif;text-align:right;";
    const btn = document.createElement("button");
    btn.textContent = "📋 Crawl → Studio";
    btn.style.cssText = "background:#111827;color:#fff;border:0;border-radius:10px;padding:12px 18px;font-size:14px;font-weight:700;box-shadow:0 4px 16px rgba(0,0,0,.35);cursor:pointer;display:block;margin-left:auto;";
    const btnTm = document.createElement("button");
    btnTm.textContent = "🎨 → Phát triển NV";
    btnTm.title = "Crawl listing này để phát triển nhân vật TM (đánh dấu riêng)";
    btnTm.style.cssText = "background:#7c3aed;color:#fff;border:0;border-radius:10px;padding:10px 16px;font-size:13px;font-weight:700;box-shadow:0 4px 16px rgba(0,0,0,.35);cursor:pointer;display:block;margin-left:auto;margin-top:8px;";
    const msg = document.createElement("div");
    msg.style.cssText = "margin-top:6px;font-size:12px;max-width:260px;padding:6px 9px;border-radius:8px;display:none;white-space:pre-wrap;margin-left:auto;";
    wrap.appendChild(btn); wrap.appendChild(btnTm); wrap.appendChild(msg);
    (document.body || document.documentElement).appendChild(wrap);

    function setMsg(t, ok) { msg.textContent = t; msg.style.display = "block"; msg.style.background = ok ? "#064e3b" : "#7f1d1d"; msg.style.color = ok ? "#bbf7d0" : "#fecaca"; }

    function crawl(purpose, theBtn) {
      btn.disabled = true; btnTm.disabled = true;
      const old = theBtn.textContent; theBtn.textContent = "Đang crawl…";
      chrome.storage.local.get(["token", "apiBase"], async (v) => {
        const token = (v.token || "").trim();
        const apiBase = ((v.apiBase || "https://cbt-crawl.vercel.app").trim()).replace(/\/$/, "");
        const done = (t, ok) => { setMsg(t, ok); btn.disabled = false; btnTm.disabled = false; theBtn.textContent = old; };
        if (!token) return done("Chưa có token. Bấm icon extension → dán crawl token → Lưu.", false);
        try {
          const isAliexpress = location.hostname.includes("aliexpress");
          const data = isAliexpress ? scrapeAliexpress() : scrapeEtsy();
          if (!data || !data.title) return done("Không đọc được dữ liệu listing trên trang này.", false);
          data.crawl_purpose = purpose;
          const r = await fetch(apiBase + "/api/etsy?action=ingest", {
            method: "POST",
            headers: { "content-type": "application/json", "x-crawl-token": token },
            body: JSON.stringify(data),
          });
          const j = await r.json().catch(() => ({}));
          if (r.ok) done((purpose === "tm" ? "✓ [Phát triển NV] " : "✓ Đã lưu: ") + (data.title || "").slice(0, 40) + "\n" + data.images.length + " ảnh · " + data.tags.length + " tags", true);
          else done("Lỗi (" + r.status + "): " + (j.error || ""), false);
        } catch (e) { done("Lỗi: " + e.message, false); }
      });
    }

    btn.onclick = () => crawl("normal", btn);
    btnTm.onclick = () => crawl("tm", btnTm);
  }

  if (document.body) build(); else document.addEventListener("DOMContentLoaded", build);
  // Etsy là SPA: nếu nút bị mất khi chuyển trang, thử gắn lại sau vài giây.
  setInterval(build, 3000);
})();
